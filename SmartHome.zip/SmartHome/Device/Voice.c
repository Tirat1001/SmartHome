#include "Voice.h"
#include "gpio.h"
#include "tim.h"

void Voice_Scan(void)
{
	if(HAL_GPIO_ReadPin(LED_IN_GPIO_Port,LED_IN_Pin))
	{
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
	}
	else
	{
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
	}

	if(HAL_GPIO_ReadPin(Curtain_IN_GPIO_Port,Curtain_IN_Pin))
	{
		HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_3);
		__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3, 250);
	}
	else
	{
		__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3, 50);
	}

	if(HAL_GPIO_ReadPin(Fan_IN_GPIO_Port,Fan_IN_Pin))
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_SET);
	}
	else
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_RESET);
	}

}
