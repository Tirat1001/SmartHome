#ifndef _DHT11_H
#define _DHT11_H

#include "main.h"

void DHT11_IO_IN(void);
void DHT11_IO_OUT(void);
void DHT11_RST(void);		//复位DHT11
uint8_t DHT11_Check(void);
uint8_t DHT11_Read_Bit(void);
uint8_t DHT11_Read_Byte(void);
uint8_t DHT11_Init(void);
//uint8_t DHT11_Read_Data(uint8_t *temp,uint8_t *humi);	//DHT11读取数据
uint8_t DHT11_Read_Data_W(void);	//DHT11读取数据
uint8_t DHT11_Read_Data_H(void);	//DHT11读取数据

#endif

