#include "MQTT.h"
#include "gpio.h"
#include "stdio.h"
#include "DHT11.h"
#include "adc.h"

uint8_t Fire;
uint8_t Data_W;
uint8_t Data_H;

#define CAL_PPM 20  // 校准环境中PPM值
#define RL			5		// RL阻值
static float R0; // 元件在洁净空气中的阻值
float ppm;
float Vrl;
float RS;

uint16_t ADC_Value;

void MQ2_PPM_Calibration(float RS)
{
    R0 = RS / pow(CAL_PPM / 613.9f, 1 / -2.074f);
}

 // MQ2传感器数据处理
float MQ2_GetPPM(void)
{
	HAL_ADC_PollForConversion(&hadc1, 100);
	ADC_Value = HAL_ADC_GetValue(&hadc1);
    Vrl = 3.3f * ADC_Value / 4095.f;
    RS = (3.3f - Vrl) / Vrl * RL;
	MQ2_PPM_Calibration(RS);
    ppm = 613.9f * pow(RS/R0, -2.074f);
    return  ppm;
}

void Scan_Data(void)
{
	if(DHT11_Read_Data_W() > 50)
	{
		Data_W = 1;
	}
	else
	{
		Data_W = 0;
	}

	if(DHT11_Read_Data_H() > 50)
	{
		Data_H = 1;
	}
	else
	{
		Data_H = 0;
	}

	if(HAL_GPIO_ReadPin(Fire_IN_GPIO_Port,Fire_IN_Pin))
	{
		Fire = 1;
	}
	else
	{
		Fire = 0;
	}

	if(MQ2_GetPPM() > 2.4)
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_SET);
	}
	else
	{
		HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, GPIO_PIN_RESET);
	}
}



void ESP8266_Lian(void)
{
	printf( "AT+RST\r\n");
	HAL_Delay(4000);
	printf( "AT+CWMODE=3\r\n" );
	HAL_Delay(4000);
	printf( "AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n" );
	HAL_Delay(4000);
	printf( "AT+CWJAP=\"jia\",\"jiawenzhe119\"\r\n" );
	HAL_Delay(4000);
	printf( "AT+MQTTUSERCFG=0,1,\"NULL\",\"smarthome&a1CXm9HNcHv\",\"5608d3c70b40b613d37c0bb55ee7c14fe63e95637fd2f36859c547b78f93efa9\",0,0,\"\"\r\n" );
	HAL_Delay(4000);
	printf( "AT+MQTTCLIENTID=0,\"a1CXm9HNcHv.smarthome|securemode=2\\,signmethod=hmacsha256\\,timestamp=1688190646940|\"\r\n" );
	HAL_Delay(4000);
	printf( "AT+MQTTCONN=0,\"a1CXm9HNcHv.iot-as-mqtt.cn-shanghai.aliyuncs.com\",1883,1\r\n");
	HAL_Delay(4000);
	//到此连接完成
	//订阅发布指令(发布数据)
	printf( "AT+MQTTSUB=0,\"/a1CXm9HNcHv/smarthome/user/get\",1\r\n");
	HAL_Delay(4000);
}
void ESP8266_Send(void)
{
	Scan_Data();
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"temperature\\\":%d}}\",1,0\r\n",DHT11_Read_Data_W());//温度
	HAL_Delay(1000);
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"Humidity\\\":%d}}\",1,0\r\n",DHT11_Read_Data_H());//湿度
	HAL_Delay(1000);
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"wdzk\\\":%d}}\",1,0\r\n",Data_W);//温度情况
	HAL_Delay(1000);
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"xdqk\\\":%d}}\",1,0\r\n",Data_H);//湿度情况
	HAL_Delay(1000);
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"GasConcentration\\\":%.1f}}\",1,0\r\n",MQ2_GetPPM());//有害气体浓度
	HAL_Delay(1000);
	printf("AT+MQTTPUB=0,\"/sys/a1CXm9HNcHv/smarthome/thing/event/property/post\",\"{\\\"params\\\":{\\\"hqyc\\\":%d}}\",1,0\r\n",Fire);//是否发现火情
	HAL_Delay(1000);
}
