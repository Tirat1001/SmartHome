#include "Door.h"
#include "gpio.h"
#include "tim.h"
#include "rc522.h"

uint8_t readUid[5];
uint8_t UID[5]={0xFB,0x29,0x0B,0x0A};

void Door_Test(void)
{
	if(HAL_GPIO_ReadPin(Face_IN_GPIO_Port,Face_IN_Pin))
	{
		HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
		__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1, 250);
	}
	else
	{
		__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1, 50);
	}

	if(!readCard(readUid,NULL))
	{
		if(!strncmp((char *)readUid,(char *)UID,4))
		{
			HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1, 250);
		}
	}
	else
	{
		__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_1, 50);
	}
}


