#ifndef __MQTT_H__
#define __MQTT_H__
#include "stm32h7xx_hal.h"

void MQ2_PPM_Calibration(float RS);
float MQ2_GetPPM(void);
void Scan_Data(void);
void ESP8266_Lian(void);
void ESP8266_Send(void);

#endif /* __MQTT_H__ */

